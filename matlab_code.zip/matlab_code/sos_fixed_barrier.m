function h = sos_fixed_barrier
pvar x1 x2
h = 1 - (x1^2+x1*x2+x2^2);
end