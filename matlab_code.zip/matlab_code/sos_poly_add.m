function f2 = sos_poly_add(a_rl)
pvar x1
f21 = x1^5/12; 
f22 = -5/3*x1^3;
f23=10*x1;
f2 = f21+f22+f23+a_rl;
end