function a = triarea(b,c)

a = b+c;