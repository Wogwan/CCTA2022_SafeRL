pwd

% function [a,t] = mat_py_test(t)
% 
% a = pwd;
% 
% end